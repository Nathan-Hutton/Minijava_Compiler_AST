package edu.westminstercollege.cmpt355.minijava;

public enum PrimitiveType implements Type {
    Int, Double, Boolean
}
