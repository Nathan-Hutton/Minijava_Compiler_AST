package edu.westminstercollege.cmpt355.minijava;

public final class VoidType implements Type {
    public static final VoidType Instance = new VoidType();
    private VoidType(){}
    public String toString() {
        return "void";
    }
}
