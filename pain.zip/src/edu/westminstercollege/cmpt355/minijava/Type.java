package edu.westminstercollege.cmpt355.minijava;

public sealed interface Type
    permits PrimitiveType, ClassType, VoidType {
}
