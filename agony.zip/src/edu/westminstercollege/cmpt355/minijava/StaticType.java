package edu.westminstercollege.cmpt355.minijava;

public final class StaticType extends ClassType {
    public StaticType(String className) {
        super(className);
    }
}
