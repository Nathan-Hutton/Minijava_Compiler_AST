package edu.westminstercollege.cmpt355.minijava.node;

import edu.westminstercollege.cmpt355.minijava.SymbolTable;
import edu.westminstercollege.cmpt355.minijava.SyntaxException;
import org.antlr.v4.runtime.ParserRuleContext;

import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;

public record PackageImport(ParserRuleContext ctx, String path) implements Import {
    @Override
    public List<? extends Node> children() {
        return List.of();
    }

    @Override
    public String getNodeDescription() {
        return "[PackageImport] " + path;
    }

    @Override
    public void typecheck(SymbolTable symbols) throws SyntaxException {
        symbols.importPackage(path);
    }

    @Override
    public void generateCode(PrintWriter out, SymbolTable symbols) {

    }
}
